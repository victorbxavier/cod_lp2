package br.ufrn.imd.controle;

public class AcimaVelocidadeException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AcimaVelocidadeException(String message) {
		super(message);
	}

}
